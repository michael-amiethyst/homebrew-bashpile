* 0.1.0 - Initial checkins.  Simple grammar, JUnit5 tests, Log4j2 logging, Bash output, *nix command line class
* 0.2.0 - Factored out translation to script language to support multiple shells
* 0.3.0 - Anonymous blocks, lexical scoping, floats
* 0.4.0 - Functions, tags
* 0.5.0 - Function forward declarations, line number comments in translated Bash
* 0.6.0 - Single line comments, Multiline Comments, BashpileDocs (like JavaDocs)
* 0.7.0 - Shell Strings, Inlines (Bash Command Substitutions)
* 0.8.0 - Create statement
* 0.9.0 - Easy running from the command line ("Drink your own champaign"/dogfooding)
* 0.10.0 - Support deployment with brew
