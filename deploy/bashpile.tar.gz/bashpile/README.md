# Bashpile
The Bash transpiler - Write in a modern language and run in any Bash shell

Full docs at [the wiki](https://github.com/designatevoid/bashpile/wiki).

## Features

In general, we hide all the hard parts of Bash scripting and handle the gotchas and quirks.  
See [the wiki](https://github.com/designatevoid/bashpile/wiki) for details!

## Install with Brew

1. brew tap michael-amiethyst/bashpile
2. brew install bashpile
